<div class="container">
    <h2>This is a about Page</h2>
    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Temporibus error officia, est iste laborum soluta architecto esse dolore fugit voluptatem!</p>
<p><?php echo e($data); ?></p>
<h3>The number of member is <?php echo e(count($arr)); ?></h3>
<?php
    $serial = 1;
?>
<?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<p> <?php echo e($serial++); ?>. <?php echo e($division); ?> </p>

    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\xampp\htdocs\Laravel\Practice\resources\views/about.blade.php ENDPATH**/ ?>