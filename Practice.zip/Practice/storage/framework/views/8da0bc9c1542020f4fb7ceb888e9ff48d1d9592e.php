
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
          <div class="col-md-12">
            <?php if(session('restore_status')): ?>
            <div class="alert alert-success">
              <?php echo e(session('restore_status')); ?>

            </div>    
            <?php endif; ?>
          </div>
          <div class="col-md-12">
            <?php if(session('hardDelete_status')): ?>
            <div class="alert alert-info">
              <?php echo e(session('hardDelete_status')); ?>

            </div>    
            <?php endif; ?>
          </div>
          <div class="col-md-12">
            <?php if(session('delete_status')): ?>
            <div class="alert alert-danger">
              <?php echo e(session('delete_status')); ?>

            </div>    
            <?php endif; ?>
          </div>
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        List Category (Active)
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead>
                              <tr>
                                <th scope="col">Serial Number</th>
                                <th scope="col">Category Name</th>
                                <th scope="col">Added By</th>
                                <th scope="col">Created Time</th>
                                <th scope="col">Updated Time</th>
                                <th scope="col">Action</th>
                              </tr>
                            </thead>
                          <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                              <tbody>  
                              <tr>
                                <td><?php echo e($loop->index+1); ?></td>
                                <td><?php echo e($category->category_name); ?></td>
                                <td><?php echo e(App\User::find($category->user_id)->name); ?></td>
                                <td>
                                <?php if($category->created_at): ?>
                                    <?php echo e($category->created_at->diffForHumans()); ?>

                                <?php else: ?>
                                    No time show
                                <?php endif; ?>
                                </td>
                                <td>
                                  <?php if($category->updated_at): ?>
                                    <?php echo e($category->updated_at->diffForHumans()); ?>

                                <?php else: ?>
                                    No time show
                                <?php endif; ?>
                                </td>
                                <td>
                                  <div class="btn-group text-white" role="group" aria-label="Basic Example">
                                    <a href="<?php echo e(url('update/category')); ?>/<?php echo e($category->id); ?>" type="button" class="btn btn-info text-white">Update</a>
                                    <a href="<?php echo e(url('delete/category')); ?>/<?php echo e($category->id); ?>" type="button" class="btn btn-danger text-white">Delete</a>
                                  </div>
                                </td>
                              </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
                              <tr>
                                <td colspan="50" class="text-center">Data is not here</td>
                              </tr>
                            </tbody>
                          <?php endif; ?>  
                        </table>
                    </div>
                </div>
                <div class="card mt-5">
                  <div class="card-header bg-danger text-white">
                      List Category (Deleted)
                  </div>
                  <div class="card-body">
                      <table class="table table-bordered">
                          <thead>
                            <tr>
                              <th scope="col">Serial Number</th>
                              <th scope="col">Category Name</th>
                              <th scope="col">Added By</th>
                              <th scope="col">Created Time</th>
                              <th scope="col">Updated Time</th>
                              <th scope="col">Action</th>
                            </tr>
                          </thead>
                          <tbody>  
                            <?php $__empty_1 = true; $__currentLoopData = $deleted_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deleted_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                              <td><?php echo e($loop->index+1); ?></td>
                              <td><?php echo e($deleted_category->category_name); ?></td>
                              <td><?php echo e(App\User::find($deleted_category->user_id)->name); ?></td>
                              <td>
                              <?php if($deleted_category->created_at): ?>
                                  <?php echo e($deleted_category->created_at->diffForHumans()); ?>

                              <?php else: ?>
                                  No time show
                              <?php endif; ?>
                              </td>
                              <td>
                                <?php if($deleted_category->updated_at): ?>
                                  <?php echo e($deleted_category->updated_at->diffForHumans()); ?>

                              <?php else: ?>
                                  No time show
                              <?php endif; ?>
                              </td>
                              <td>
                                <div class="btn-group text-white" role="group" aria-label="Basic Example">
                                  <a href="<?php echo e(url('restore/category')); ?>/<?php echo e($deleted_category->id); ?>" type="button" class="btn btn-success text-white">Restore</a>
                                  <a href="<?php echo e(url('harddelete/category')); ?>/<?php echo e($deleted_category->id); ?>" type="button" class="btn btn-danger text-white">P.Delete</a>
                                </div>
                              </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
                            <tr>
                              <td colspan="50" class="text-center">Data is not here</td>
                            </tr>
                            <?php endif; ?>  
                          </tbody>
                      </table>
                  </div>
              </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        Add Category
                    </div>
                    <div class="card-body">
                      <?php if(session('success_message')): ?>
                      <div class="alert alert-success">
                          <?php echo e(session('success_message')); ?>

                      </div>
                      <?php endif; ?>
                        <form method="POST" action="<?php echo e(url('/add/category/post')); ?>">
                          <?php echo csrf_field(); ?>
                            <div class="form-group">
                              <label for="exampleInputEmail1">Category Name</label> 
                              <input type="text" class="form-control" name="category_name" placeholder="Enter Category Name">
                            </div>
                            <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger">
                                  <?php echo e($message); ?>

                                </div> 
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <button type="submit" class="btn btn-success">Add Category</button>
                          </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Practice\resources\views//admin/category/index.blade.php ENDPATH**/ ?>