
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-4 m-auto">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item"><a href="<?php echo e(url('add/category')); ?>">Add Category</a></li>
                      <li class="breadcrumb-item active" aria-current="page"><?php echo e($category_name); ?></li>
                    </ol>
                  </nav>
                <div class="card">
                    <div class="card-header">
                        Update Category
                    </div>
                    <div class="card-body ">
                        <?php if(session('update_status')): ?>
                      <div class="alert alert-success">
                          <?php echo e(session('update_status')); ?>

                      </div>
                      <?php endif; ?>
                        <form method="post" action="<?php echo e(url('/update/category/post')); ?>">
                          <?php echo csrf_field(); ?>
                            <div class="form-group">
                              <label for="exampleInputEmail1">Category Name</label> 
                              <input type="hidden" name="category_id" value="<?php echo e($category_id); ?>">
                              <input type="text" class="form-control" name="category_name" value="<?php echo e($category_name); ?>">
                            </div>
                            <button type="submit" class="btn btn-success">Update Category</button>
                          </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Practice\resources\views/admin/category/update.blade.php ENDPATH**/ ?>