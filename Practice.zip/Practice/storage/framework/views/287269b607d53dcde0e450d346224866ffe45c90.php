
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-6 m-auto">
            <div class="card">
                <div class="card-header">
                    Edit Your Profile
                </div>
                <div class="card-body">
                  <?php if(session('success_message')): ?>
                  <div class="alert alert-success">
                      <?php echo e(session('success_message')); ?>

                  </div>
                  <?php endif; ?>
                    <form method="POST" action="<?php echo e(url('/profile/post')); ?>">
                      <?php echo csrf_field(); ?>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Name</label> 
                          <input type="text" class="form-control" name="name" placeholder="Change your Name" value="<?php echo e(Str::title(Auth::user()->name)); ?>">
                        </div>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                              <?php echo e($message); ?>

                            </div> 
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <button type="submit" class="btn btn-success">Change Profile</button>
                      </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-5">
        <div class="col-md-6 m-auto">
            <div class="card">
                <div class="card-header">
                    Change Password
                </div>
                <div class="card-body">
                  <?php if(session('password_change_status')): ?>
                  <div class="alert alert-success">
                      <?php echo e(session('password_change_status')); ?>

                  </div>
                  <?php endif; ?>
                  <?php if($errors->all()): ?>
                  <div class="alert alert-danger">
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                  <?php endif; ?>
                    <form method="POST" action="<?php echo e(url('password/post')); ?>">
                      <?php echo csrf_field(); ?>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Old Password</label> 
                          <input type="password" class="form-control" name="old_password" placeholder="Write Old Password" value="<?php echo e(old('old_password')); ?>">
                        </div>
                        <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                              <?php echo e($message); ?>

                            </div> 
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="form-group">
                            <label for="exampleInputEmail1">New Password</label> 
                            <input type="password" class="form-control" name="password" placeholder="Write New Password" value="<?php echo e(old('password')); ?>">
                          </div>
                          <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                              <?php echo e($message); ?>

                            </div> 
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          <div class="form-group">
                            <label for="exampleInputEmail1">Confirm Password</label> 
                            <input type="password" class="form-control" name="password_confirmation" placeholder="Write Confirm Password" value="">
                          </div>
                        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                              <?php echo e($message); ?>

                            </div> 
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <button type="submit" class="btn btn-info">Change Password</button>
                      </form>
                </div>
            </div>
        </div> 
    </div>   
        
    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Practice\resources\views/admin/profile/index.blade.php ENDPATH**/ ?>