<div class="container">
<h2>This is a Contact page</h2>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Velit tenetur ab unde numquam repudiandae beatae ipsa praesentium. Nulla, facilis harum.</p>
</div><?php /**PATH C:\xampp\htdocs\laravel\Practice\resources\views/contact.blade.php ENDPATH**/ ?>