<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card bg-secondary">
                <div class="card-header"><h3><?php echo e(__('Dashboard')); ?></h3></div>

                <div class="card-body bg-success">
                    <h1>Welcome <?php echo e(auth::user()->name); ?></h1>
                    <h2>Email: <?php echo e(auth::user()->email); ?></h2>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-3">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-info"> 
                    <h2>Total user: <?php echo e($total_users); ?></h2>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                          <tr>
                            <th scope="col">Serial No.</th>
                            <th scope="col">ID</th>
                            <th scope="col">Name</th>
                            <th scope="col">Email</th>   
                            <th scope="col">Create time</th>   
                          </tr>
                        </thead>
                        <tbody>
                            <?php
                                $serial = 1;
                            ?>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($users->firstItem() + $loop->index); ?></td>
                            <td><?php echo e($user->id); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><li><?php echo e($user->created_at->format('d-M-y  h:i:s A')); ?></li>
                                <li><?php echo e($user->created_at->diffForHumans()); ?></li>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>  
                    </table>
                    <?php echo e($users->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Practice\resources\views/home.blade.php ENDPATH**/ ?>